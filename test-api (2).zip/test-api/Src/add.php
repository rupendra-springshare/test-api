<?php declare( strict_types=1 );
require_once __DIR__ . '/../vendor/autoload.php';

use App\Entity\BugReport;
use App\Repository\BugReportRepository;
use App\Helpers\DbQueryBuilderFactory;
use App\Database\QueryBuilder;
use App\Logger\Logger;
use App\Exception\BadRequestException;

if(isset($_POST, $_POST['add'])){
    $reportType = $_POST['reportType'];
    $email = $_POST['email'];
    $link = $_POST['link'];
    $message = $_POST['message'];
	
	
	 if( $reportType =='google' ) {
	
	$apiKey = 'AIzaSyAiXjlLRIAZtK4c5O4CP_b0wLzNOJ4MOGY';
	$address = str_replace(" ", "+", $message);
    $url = "https://maps.google.com/maps/api/geocode/json?address=".urlencode($address)."&sensor=false&key=".$apiKey;
    $json = file_get_contents($url);
    $json = json_decode($json);
	
	
	$lat = $json->{'results'}[0]->{'geometry'}->{'location'}->{'lat'};
    $long = $json->{'results'}[0]->{'geometry'}->{'location'}->{'lng'}; 
	 } else {
	// url encode the address
    $address = urlencode($_POST['message']);

    $url = "https://nominatim.openstreetmap.org/?format=json&addressdetails=1&q={$address}&format=json&limit=1";


    // get the json response
    $resp_json = file_get_contents($url);

    // decode the json
    $resp = json_decode($resp_json, true);
	
	$lat = $resp[0]['lat'];
	
	$long = $resp[0]['lon'];
	
	 }
    
	
    $bugReport = new BugReport;
    $bugReport->setReportType($reportType);
    $bugReport->setEmail($lat);
    $bugReport->setLink($long);
    $bugReport->setMessage($message);

    $logger = new Logger;
    try{
        /** @var QueryBuilder $queryBuilder */
        $queryBuilder = DbQueryBuilderFactory::make();
        /** @var BugReportRepository $repository */
        $repository = new BugReportRepository($queryBuilder);
        /** @var BugReport $newReport */
        $newReport = $repository->create($bugReport);
    }catch (Throwable $exception){
        $logger->critical($exception->getMessage(), $_POST);
        throw new BadRequestException($exception->getMessage(), [$exception], 400);
    }

    $logger->info(
        'new bug report created',
        ['id' => $newReport->getId(), 'type' => $newReport->getReportType(),]
    );
    $bugReports = $repository->findAll();
}