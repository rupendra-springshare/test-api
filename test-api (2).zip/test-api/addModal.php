
<!-- Add Report Modal HTML -->
<div id="addBugReportModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post">
                <div class="modal-header">
                    <h4 class="modal-title">Submit Report</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>API Type</label>
                        <select name="reportType" class="form-control" required>
                            
                           <option value="google">Google</option>
                                                        <option value="osm">OSM</option>
                        </select>
                    </div>
                   
                       
                        <input type="hidden" name="email" class="form-control" value="no">
                  
                    <div class="form-group">
                        <label>Message</label>
                        <textarea class="form-control" name="message" required></textarea>
                    </div>
                    
                        <input type="hidden" class="form-control" name="link" id="link" value="yes">
                   
                <div class="modal-footer">
                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                    <input type="submit" class="btn btn-success" name="add" value="Add">
                </div>
            </form>
        </div>
    </div>
</div>

