# API-geocode-OSM-app

Build A lattitude and logitude based on  with PHP OOP no Dependencies 


Object Oriented PHP with PHPUnit from Scratch

You need to provide API-KEY to get latitude and logitude based on address


In this course you will:

    Understand Object Oriented PHP with design patterns


    Learn how and why you should use dependency inversion principle and dependency injection

    Implement some common design patterns using PHP

    Build a database wrapper with support for PDO and MySQLi

    Gain a sense of when to use basic language features

